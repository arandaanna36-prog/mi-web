# 📖 Escribo para no olvidar

Bienvenidos al repositorio de **Anni Gvnni** ✨.  
Este proyecto contiene mi libro completo **"Escribo para no olvidar"**, acompañado de un pequeño sitio web hecho en HTML, listo para ser publicado con **GitHub Pages**.

---

## 🌍 Ver el libro online
Cuando actives **GitHub Pages** en este repositorio, tu libro estará disponible en un link como:  

👉 `https://tu-usuario.github.io/mi-web/`  

*(Reemplaza `tu-usuario` por tu nombre de usuario en GitHub.)*

---

## 📂 Contenido del repositorio
- `index.html` → Página principal que muestra el libro.  
- `favicon.png` → Ícono con las iniciales **AG** que aparece en la pestaña del navegador.  
- `README.md` → Archivo de presentación del proyecto.  

---

## 🚀 Cómo publicarlo en GitHub Pages
1. Ve a la pestaña **Settings** del repositorio.  
2. Busca la sección **Pages**.  
3. En **Source**, selecciona:  
   - **Deploy from a branch**  
   - Rama: **main**  
   - Carpeta: **root**  
4. Haz clic en **Save**.  
5. Espera unos segundos, y tu libro estará disponible en la URL que GitHub te indique. 🎉  

---

## 💜 Autor
**Anni Gvnni**  
*"Escribo para no olvidar"* es un viaje íntimo a través de cartas, sueños y memorias, compartidas para sanar, recordar y transformar.
